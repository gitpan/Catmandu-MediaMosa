package Catmandu::MediaMosa::Items;
use Catmandu::Sane;
use Moo::Role;

requires qw(parse parse_xpath);

1;
